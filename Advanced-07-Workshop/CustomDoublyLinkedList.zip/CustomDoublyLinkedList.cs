﻿namespace CustomDoublyLinkedList
{
    using System;
    using System.Collections;
    using System.Collections.Generic;

    public class CustomDoublyLinkedList<T> : IEnumerable<T>
    {
        private class ListNode //клас в клас, ако искам този клас да се ползва само от горния клас
        {
            public T Value { get; private set; }

            public ListNode NextNode { get; set; }

            public ListNode PreviousNode { get; set; }

            public ListNode(T value)
            {
                this.Value = value;
            }
        }

        private ListNode head;
        private ListNode tail;
        public int Count { get; private set; }

        public T Head
        {
            get
            {
                this.CheckIfIsEmpty();
                return this.head.Value;
            }
        }

        public T Tail
        {
            get
            {
                this.CheckIfIsEmpty();
                return this.tail.Value;
            }
        }


        public void AddFirst(T value)
        {
            var newNode = new ListNode(value);

            if (this.Count == 0)
            {
                this.head = this.tail = newNode;
            }
            else
            {
                var oldHead = this.head;
                oldHead.PreviousNode = newNode;
                newNode.NextNode = oldHead;
                this.head = newNode;
            }

            this.Count++;
        }

        public void AddLast(T value)
        {
            var newNode = new ListNode(value);

            if (this.Count == 0)
            {
                this.head = this.tail = newNode;
            }
            else
            {
                var oldTail = this.tail;
                oldTail.NextNode = newNode;
                newNode.PreviousNode = oldTail;
                this.tail = newNode;
            }

            this.Count++;
        }

        public void Clear()
        {

            this.head = null;
            this.tail = null;
            this.Count = 0;
        }

        public bool Contains(T value)
        {
            var currentNode = this.head;
            while (currentNode != null)
            {
                if (currentNode.Value.Equals(value))
                {
                    return true;
                }

                currentNode = currentNode.NextNode;
            }
            return false;
        }

        public void Remove(T value)
        {
            var currentNode = this.head;

            while (currentNode != null)
            {
                var nodeValue = currentNode.Value;

                if (nodeValue.Equals(value))
                {
                    var previousNode = currentNode.PreviousNode;
                    var nextNode = currentNode.NextNode;

                    if (previousNode != null)
                    {
                        previousNode.NextNode = nextNode;
                    }

                    if (nextNode != null)
                    {
                        nextNode.PreviousNode = previousNode;
                    }

                    if (this.head == currentNode)
                    {
                        this.head = nextNode;
                    }

                    if (this.tail == currentNode)
                    {
                        this.tail = previousNode;
                    }
                    this.Count--;
                }

                currentNode = currentNode.NextNode;
            }
        }

        public T RemoveFirst()
        {
            this.CheckIfIsEmpty();

            var value = this.head.Value;

            if (this.head == this.tail)
            {
                this.head = null;
                this.tail = null;
            }
            else
            {
                var newHead = this.head.NextNode;
                newHead.PreviousNode = null;
                this.head.NextNode = null;
                this.head = newHead;
            }

            this.Count--;
            return value;
        }

        public T RemoveLast()
        {
            this.CheckIfIsEmpty();

            var value = this.tail.Value;

            if (this.head == this.tail)
            {
                this.head = null;
                this.tail = null;
            }
            else
            {
                var newTail = this.tail.PreviousNode;
                this.tail.PreviousNode = null;
                newTail.NextNode = null;
                this.tail = newTail;
            }

            this.Count--;
            return value;
        }

        public void ForEach(Action<T> action)
        {
            var currentNode = this.head;
            while (currentNode != null)
            {
                action(currentNode.Value);
                currentNode = currentNode.NextNode;
            }
        }

        public T[] ToArray()
        {
            var array = new T[this.Count];

            var currentNode = this.head;
            var index = 0;

            while (currentNode != null)
            {
                array[index] = currentNode.Value;
                index++;
                currentNode = currentNode.NextNode;
            }

            return array;
        }

        private void CheckIfIsEmpty()
        {
            if (this.Count == 0)
            {
                throw new InvalidOperationException("Customs Linked List is empty!");
            }
        }

        public IEnumerator<T> GetEnumerator()
        {
            var currentNode = this.head;

            while (currentNode != null)
            {
                yield return currentNode.Value;
                currentNode = currentNode.NextNode;
            }
        }

        IEnumerator IEnumerable.GetEnumerator() => this.GetEnumerator();
    }
}