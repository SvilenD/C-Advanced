﻿namespace CustomDoublyLinkedList
{
    using System;

    public class StartUp
    {
        public static void Main()
        {
            //var linkedList = new CustomDoublyLinkedList<int>();

            //linkedList.AddFirst(5);
            //linkedList.AddFirst(10);
            //linkedList.AddFirst(15);

            ////15 <-> 10 <-> 5

            //Console.WriteLine(linkedList.Count == 3);
            //Console.WriteLine(linkedList.Head == 15);
            //Console.WriteLine(linkedList.Tail == 5);
            //linkedList.AddLast(20);
            //linkedList.AddLast(25);

            ////15 <-> 10 <-> 5 <-> 20 <-> 25
            //linkedList.ForEach(Console.WriteLine);

            //Console.WriteLine(linkedList.Count == 5);
            //Console.WriteLine(linkedList.Head == 15);
            //Console.WriteLine(linkedList.Tail == 25);

            //Console.WriteLine(linkedList.RemoveFirst() == 15);
            //Console.WriteLine(linkedList.RemoveFirst() == 10);
            //Console.WriteLine(linkedList.Count == 3);

            ////5 <-> 20 <-> 25
            //Console.WriteLine(linkedList.RemoveLast() == 25);
            //Console.WriteLine(linkedList.RemoveLast() == 20);
            //Console.WriteLine(linkedList.RemoveLast() == 5);
            //Console.WriteLine(linkedList.Count == 0);

            //try
            //{
            //    Console.WriteLine(linkedList.Head);
            //    Console.WriteLine(false);
            //}
            //catch (InvalidOperationException)
            //{
            //    Console.WriteLine(true);
            //}

            //var newList = new CustomDoublyLinkedList<int>();
            //newList.AddFirst(10);
            //newList.AddFirst(1);
            //newList.AddLast(10);
            //newList.AddLast(100);
            //newList.AddFirst(10);

            //foreach (var num in newList)
            //{
            //    Console.WriteLine(num);
            //}

            //Console.WriteLine(newList.Contains(22) == false);
            //Console.WriteLine(newList.Contains(1));
            //Console.WriteLine(newList.Count == 5);
            //newList.Remove(10);
            //Console.WriteLine(newList.Count == 2);
            //newList.Clear();
            //Console.WriteLine(newList.Count == 0);
            //Console.WriteLine(newList.Contains(5) == false);
        }
    }
}