﻿namespace DefiningClasses
{
    using System.Linq;
    using System.Collections.Generic;

    public class Family
    {
        public List<Person> ListOfPeople { get; private set; } = new List<Person>();

        public void AddMember(Person member)
        {
            ListOfPeople.Add(member);
        }

        public Person GetOldestMember()
        {
            var person = ListOfPeople.FirstOrDefault(p => p.Age == ListOfPeople.Max(x => x.Age));
            return person;
        }
    }
}
