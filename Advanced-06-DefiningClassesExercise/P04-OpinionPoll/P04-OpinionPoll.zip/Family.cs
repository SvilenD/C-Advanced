﻿namespace DefiningClasses
{
    using System.Linq;
    using System.Collections.Generic;

    public class Family
    {
        private List<Person> ListOfPeople = new List<Person>();

        public void AddMember(Person member)
        {
            ListOfPeople.Add(member);
        }

        public List<Person> AgeFilter(int parameter)
        {
            List<Person> filteredPeople = ListOfPeople.Where(p => p.Age > 30).ToList();
            return filteredPeople;
        }
    }
}