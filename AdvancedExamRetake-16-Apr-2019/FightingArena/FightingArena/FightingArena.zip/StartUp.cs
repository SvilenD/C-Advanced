﻿namespace FightingArena
{
    using System;
    public class StartUp
    {
        public static void Main()
        {
        }
    }
}