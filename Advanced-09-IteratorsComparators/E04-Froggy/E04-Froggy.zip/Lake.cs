﻿namespace Froggy
{
    using System;
    using System.Collections;
    using System.Collections.Generic;

    public class Lake : IEnumerable<int>
    {
        private int[] stones;

        public Lake(int[] input)
        {
            this.stones = ArrangeStones(input);
        }

        private int[] ArrangeStones(int[] input)
        {
            var oddStones = new Queue<int>();
            var evenStones = new Stack<int>();

            for (int i = 0; i < input.Length; i += 2)
            {
                oddStones.Enqueue(input[i]);
            }
            for (int i = 1; i < input.Length; i += 2)
            {
                evenStones.Push(input[i]);
            }
            var arranged = new int[input.Length];
            Array.Copy(oddStones.ToArray(), 0, arranged, 0, oddStones.Count);
            Array.Copy(evenStones.ToArray(), 0, arranged, oddStones.Count, arranged.Length - oddStones.Count);

            return arranged;
        }


        public IEnumerator<int> GetEnumerator()
        {
            for (int i = 0; i < this.stones.Length; i++)
            {
                yield return stones[i];
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }
    }
}