﻿namespace Froggy
{
    using System;
    using System.Linq;

    public class Program
    {
        public static void Main()
        {
            var input = new Lake(Console.ReadLine()
                .Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(int.Parse)
                .ToArray());

            Console.WriteLine($"{string.Join(", ", input)}");
        }
    }
}