﻿namespace GenericScale
{
    public class EqualityScale<T>
    {
        public EqualityScale(T left, T right)
        {
            this.left = left;
            this.right = right;
        }

        private T left;
        private T right;

        public bool AreEqual()
        {
            if (left.Equals(right))
            {
                return true;
            }
            return false;
        }
    }
}