﻿namespace MergeSort
{
    using System;
    using System.Linq;

    public class Program
    {
        static void Main()
        {
            string input = Console.ReadLine();

            if (input == String.Empty)
            {
                return;
            }

            int[] arr = input
                .Split()
                .Select(int.Parse)
                .ToArray();

            MergeSort<int>.Sort(arr);

            Console.WriteLine(String.Join(" ", arr));
        }
    }
}

